package com.project.AutoDeelsoftwareproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class notifications extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notifications);
    }

//    public void onClick(View view){
//        Intent intent = new Intent(getApplicationContext(), payment.class);
//    }
//    Intent intent = new Intent(this, payment.class);

}
